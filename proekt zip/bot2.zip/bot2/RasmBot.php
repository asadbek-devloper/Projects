<?php
ob_start();



define('boqiyevdev',"6563401822:AAEkg50tNuPcNhYmVQiDQjJKlhf6vrgfPEQ"); 

$admin = '5873817487'; 
$adminuser = "boqiyev07"; 
$yalqovcoder ="Tabrik_yang_yil_bot";

function bot($method,$datas=[]){
global $token;
$url = "https://api.telegram.org/bot".Tabrik_yang_yil_bot."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$mid = $message->message_id;
$data = $update->callback_query->data;
$type = $message->chat->type;
$text = $message->text;
$cid = $message->chat->id;
$chat_id = $message->chat->id;
$uid= $message->from->id;
$message = $update->message;
$cid = $message->chat->id;
$cidtyp = $message->chat->type;
$miid = $message->message_id;
$name = $message->chat->first_name;
$user1 = $message->from->username;
$tx = $message->text;
$callback = $update->callback_query;
$mmid = $callback->inline_message_id;
$data = $callback->data;
$cbins = $callback->chat_instance;
$cbchtyp = $callback->message->chat->type;
$step = file_get_contents("step/$cid.step");
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$mid = $message->message_id;
$msgs = json_decode(file_get_contents('msgs.json'),true);
$data = $update->callback_query->data;
$type = $message->chat->type;
$text = $message->text;
$cid = $message->chat->id;
$uid= $message->from->id;
$name = $message->from->first_name;
$bio = $messenge->from->about;
$username = $message->from->username;
$cusername = $message->chat->username;
$repmid = $message->reply_to_message->message_id; 
$ccid = $update->callback_query->message->chat->id;
$cuid = $update->callback_query->message->from->id;
$photo = $message->photo;
$name = $message->from->first_name;
$userini = $message->from->username;
$xursandbek = file_get_contents("data/$from_id/yalqovcoder.txt");
$Yalqov1 = file_get_contents("data/$from_id/Yalqov1.txt");
$Yalqov2 = file_get_contents("data/$from_id/Yalqov2.txt");
$to =  file_get_contents("data/$from_id/token.txt");
$url =  file_get_contents("data/$from_id/url.txt");

$menu = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"☃️Rasm Tayyorlash⛄"],],
[['text'=>"🎄Yangi Yil🌲"],['text'=>"♻️Yangilash♻️"],],
[['text'=>"🗞Yangiliklar🗞"],['text'=>"❄Dasturchi❄"],],
]
]);


$rasmt = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"1"],['text'=>"2"],],
[['text'=>"3"],['text'=>"4"]], 
[['text'=>"5"],['text'=>"6"],],
]
]);

$ret1 = bot("getChatMember",[
         "chat_id"=>"@YalqovCoder",
         "user_id"=>$uid
         ]);
$ret2 = bot("getChatMember",[
         "chat_id"=>"@AnonimXacker", 
         "user_id"=>$uid
         ]);
$stat1 = $ret1->result->status;
$stat2 = $ret2->result->status;

         if(($stat1=="creator" or $stat1=="administrator" or $stat1=="member") and ($stat2=="creator" or $stat2=="administrator" or $stat2=="member")){}else{
     bot("sendmessage",[
         "chat_id"=>$uid,
         "text"=>"⛄<b>Quyidagi kanalimizga obuna boling. A'zo bo'lib qayta /start bosing! Botni keyin toliq ishlatishingiz mumkin!</b>",
         'disable_web_page_preview'=>true,
         'parse_mode'=>'html',
         "reply_to_message_id"=>$mid,
"reply_markup"=>json_encode([
"inline_keyboard"=>[
[["text"=>"🌬Kanalga kirish🌬","url"=>"https://t.me/YalqovCoder"],],
[["text"=>"🌬Kanalga kirish🌬","url"=>"https://t.me/AnonimXacker"],],
[["text"=>"🌬Kanalga kirish🌬","url"=>"https://t.me/Amudaryo_chatiii"],],
]
]),
]); 
return false;
}


if($text=="❌Orqaga"){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"⛄<b>Siz Bosh menyudasiz.</b>",
'parse_mode'=>'html',
'reply_to_message_id'=> $mid, 
'reply_markup'=>$menu
]);
}


if($type=="private"){
if($text=="/start"){
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"⛄Assalomu Alaykum $name

❄: Men orqali ismingiz ajoyib rasmga joylashingiz mumkin!

🌲Buning uchun pastdagi bo'limlarni birini tanlang👇",
'parse_mode'=>'html',
'reply_to_message_id'=> $mid, 
'reply_markup'=>$menu,
]);
bot('sendmessage',[
'chat_id'=>$admin,
'text'=>"🌬Diqqat <a href = 'tg://user?id=$cid'>$name</a>⛄ Botga /start Bosdi!
<b>🌨Usernamesi:</b> @$userini
<b>🎄Raqami:</b> <code>$cid</code>",
'parse_mode'=>'html',
]);
}}


$lichka=file_get_contents("YalqovCoder.db");
if($type=="private"){
if(strpos($lichka,"$cid") !==false){
}else{
file_put_contents("YalqovCoder.db","$lichka\n$cid");
}
}

if($tx == "/stat"){
if($cid == $admin){
$lichka=file_get_contents("YalqovCoder.db");
$lich=substr_count($lichka,"\n");
$okun=date("n");
$oynoms = "1Yanvar1 2Fevral2 3Mart3 4Aprel4 5May5 6Iyun6 7Iyul7 8Avgust8 9Sentabr9 10Oktabr10 11Noyabr11 12Dekabr12";
$ex2 = explode("$okun",$oynoms);
$oy = "$ex2[1]";
$kun = date("d",strtotime("2 hour"));
$kunlar = date("d.m",strtotime("2 hour"));
$soat = date("H:i:s",strtotime("2 hour"));
$yil = date('Y',strtotime('2 hour'));
$sana="📆Hozir: $yil-Yil, $kun-$oy, $soat";
bot('sendmessage',[
'chat_id'=>$cid,
    'text'=> "❄<b>Bot azolari:</b>    
👥A'zolar: <b>$lich</b>
⛄Kanalimiz: <b>@$yalqovcoder</b>

❄Bugingi Sana: $sana ",
'parse_mode' => 'html',
]);
}
}
//yangi yil
if($text=="🎄Yangi Yil🌲"){
  $kun1 = date('z ',strtotime('2 hour')); 
  $a = 365;
  $c2 = $a-$kun1;
  $d = date('L ',strtotime('2 hour'));
  $b = $c2+$d;
  $f = $b+81;
  $e = $b+240;
  $kun2 = date('H ',strtotime('2 hour')); 
  $a2 = 23;
  $b2 = $a2-$kun2;
  $kun3 = date('i ',strtotime('2 hour')); 
  $a3 = 59;
  $b3 = $a3-$kun3;
  $kun4 = date('s ',strtotime('2 hour')); 
  $a4 = 60;
  $b4 = $a4-$kun4;
  $mmtxt="
☃️Yangi yilga Bayramiga

 🎄$b kun 
 🎊$b2 soat
 🎁 $b3 minut
 ❄️$b4 sekund qoldi!

🎅🏽Hurmatli '$name' 
🎉Kirib kelayotgan
🎁Yangi yil bilan! ";
  bot('sendmessage',[
    'chat_id'=>$chat_id,
    'user_id'=>$cid,
    'reply_to_message_id'=>$mid,
    'text'=>$mmtxt,
    'parse_mode'=>'html',
'reply_markup'=>$menu,
  ]);
}


if($text == "🗞Yangiliklar🗞"){
bot('sendMessage', [
'chat_id'=>$cid,
'text'=>"
❄Eng So'ngi va Qaynoq Yangiliklar

khursandbek.uz

🌨To'liq O'qish Uchun Bosing!⤴️",
'parse_mode'=>'Markdown',
'reply_to_message_id'=> $mid, 
'reply_markup'=>$menu, 
]);
}

if($text == "❄Dasturchi❄"){
bot('sendMessage', [
'chat_id'=>$cid,
'text'=>"
❄Dasturchi: @YalqovCoder 

🌨Sayt: www.khursandbek.uz",
'parse_mode'=>'Markdown',
'reply_to_message_id'=> $mid, 
'reply_markup'=>$menu, 
]);
}

if($text == "⛄Rasm Tayorlash"){
bot('sendMessage', [
'chat_id'=>$cid,
'text'=>"
❄Kerakli Sini Tanlang !",
'parse_mode'=>'Markdown',
'reply_to_message_id'=> $mid, 
'reply_markup'=>$rasmt, 
]);
}

//Ismlar manosi

//yangilash
if($text == "♻️Yangilash♻️"){
bot('sendMessage',[
 'chat_id'=>$chat_id,
 'text'=>"⛄Ya'lumotlar Yangilanmoqda...",
 'parse_mode'=>"HTML"
 ]);
 sleep(1.1);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'text'=>'🌪Yangilanmoqda... 0%🌨
🦠🦠🦠🦠🦠🦠🦠🦠🦠🌬'
 ]);
 sleep(0.5);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid +1,
 'text'=>'🌪Yangilanmoqda... 10%🌨
🦠🦠🦠🦠🦠🦠🦠🦠🌬??'
 ]);
 sleep(0.5);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'🌪Yangilanmoqda... 20%🌨🌨
🦠🦠🦠🦠🦠🦠🦠🌬🦠🦠'
 ]);
 sleep(0.5);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'🌪Yangilanmoqda... 30%🌨🌨🌨
🦠🦠🦠🦠🦠🦠🌬🦠🦠🦠'
 ]);
 sleep(0.5);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'🌪Yangilanmoqda... 40%🌨🌨🌨🌨
🦠🦠🦠🦠🦠🌬🦠🦠🦠🦠'
 ]);
 sleep(0.5);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'🌪Yangilanmoqda... 50% 🌨🌨🌨🌨🌨
🦠🦠🦠🦠🌬🦠🦠🦠🦠🦠'
 ]);
 sleep(0.5);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'🌪Yangilanmoqda... 60%🌨🌨🌨🌨🌨🌨
🦠🦠🦠🌬🦠🦠🦠🦠🦠🦠'
 ]);
 sleep(0.5);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'🌪Yangilanmoqda... 70%🌨🌨🌨🌨🌨🌨🌨
🦠🦠🌬🦠🦠🦠🦠🦠🦠🦠'
 ]); 
 sleep(0.5);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'🌪Yangilanmoqda... 80%🌨🌨🌨🌨🌨🌨🌨🌨
🦠🌬🦠🦠🦠🦠🦠🦠🦠🦠'
]);
 sleep(0.5);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'🌪Yangilanmoqda... 90%🌨🌨🌨🌨🌨🌨🌨🌨🌨
🌬🦠🦠🦠🦠🦠🦠🦠🦠🦠'
 ]);
 sleep(0.5);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'🎄Yangilandi '
 ]); 
 sleep(0.7);
  bot('deletemessage',[
    'chat_id'=>$chat_id,
    'message_id'=>$mid + 1,
  ]);
 sleep(0.7);
 bot('sendMessage', [
'chat_id'=>$cid,
'text'=>"
🎄Barcha Ma'lumotlar Yangilandi!

",
'parse_mode'=>'html',
'reply_to_message_id'=> $mid, 
'reply_markup'=>$menu, 
]);
}

if($text=="1" || $text == "🎉Yana (1)"){
file_put_contents("data/$from_id/Yalqov1.txt", 'to');
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"🎄Ismingizni yozib ⛄Menga Yuboring!
❄Men Sizga Rasm Tayyorlab beraman!",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'resize_keyboard'=>false,
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"❌Orqaga"]],

]
])
]);
}
elseif($Yalqov1 == "to"){
$ex=$text;
$ex=$text;
bot('SendMessage',[
'chat_id'=>$chat_id,
 'text'=>"🌨Iltimos biroz kuting, buyurtmangiz hozir tayyor bo'ladi...",
 'parse_mode'=>"HTML"
 ]);
 sleep(1.1);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'text'=>'⛄Tayyorlanmoqda...
☁☁☁☁☁☁☁☁☁☁ 0% 0️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid +1,
 'text'=>'⛄Tayyorlanmoqda...
🌨☁☁☁☁☁☁☁☁☁ 10% 1️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨☁☁☁☁☁☁☁☁ 20% 2️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨☁☁☁☁☁☁☁ 30% 3️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨☁☁☁☁☁☁ 40% 4️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨☁☁☁☁☁ 50% 5️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨☁☁☁☁ 60% 6️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨☁☁☁ 70% 7️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨☁☁ 80% 8️⃣'
]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨🌨☁ 90% 9️⃣'
 ]);
 sleep(0.3);
 bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨🌨🌨 100% 🔟'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$cid,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyor 100%🎉'
 ]); 
  bot('deletemessage',[
    'chat_id'=>$cid,
    'message_id'=>$mid + 1,
  ]);
 sleep(0.5);
bot('sendphoto',[
'chat_id'=>$cid,
'photo'=>"http://u8481.xvest6.ru/Apilar/Fildirbot/Yigitlar/1/2.php?text=$ex",
'caption'=>"⛄Buyurtma qilgan Rasmingiz tayyor bo'ldi!
🎄Ismingiz: $ex

",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'resize_keyboard'=>false,
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🎉Yana (1)"],['text'=>"❌Orqaga"]],
]
])
]);
unlink("data/$from_id/Yalqov1.txt");
exit();
}

if($text=="6" || $text == "6"){
file_put_contents("data/$from_id/Yalqov1.txt", 'to');
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"🎄Ismingizni yozib ⛄Menga Yuboring!
❄Men Sizga Rasm Tayyorlab beraman!",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'resize_keyboard'=>false,
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"❌Orqaga"]],

]
])
]);
}
elseif($Yalqov1 == "to"){
$ex=$text;
$ex=$text;
bot('SendMessage',[
'chat_id'=>$chat_id,
 'text'=>"🌨Iltimos biroz kuting, buyurtmangiz hozir tayyor bo'ladi...",
 'parse_mode'=>"HTML"
 ]);
 sleep(1.1);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'text'=>'⛄Tayyorlanmoqda...
☁☁☁☁☁☁☁☁☁☁ 0% 0️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid +1,
 'text'=>'⛄Tayyorlanmoqda...
🌨☁☁☁☁☁☁☁☁☁ 10% 1️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨☁☁☁☁☁☁☁☁ 20% 2️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨☁☁☁☁☁☁☁ 30% 3️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨☁☁☁☁☁☁ 40% 4️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨☁☁☁☁☁ 50% 5️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨☁☁☁☁ 60% 6️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨☁☁☁ 70% 7️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨☁☁ 80% 8️⃣'
]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨🌨☁ 90% 9️⃣'
 ]);
 sleep(0.3);
 bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨🌨🌨 100% 🔟'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$cid,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyor 100%🎉'
 ]); 
  bot('deletemessage',[
    'chat_id'=>$cid,
    'message_id'=>$mid + 1,
  ]);
 sleep(0.5);
bot('sendphoto',[
'chat_id'=>$cid,
'photo'=>"http://u8481.xvest6.ru/Apilar/Fildirbot/Qizlarga/3/2.php?text=$ex",
'caption'=>"⛄Buyurtma qilgan Rasmingiz tayyor bo'ldi!
🎄Ismingiz: $ex

",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'resize_keyboard'=>false,
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"6"],['text'=>"❌Orqaga"]],
]
])
]);
unlink("data/$from_id/Yalqov1.txt");
exit();
}

if($text=="5" || $text == "5"){
file_put_contents("data/$from_id/Yalqov1.txt", 'to');
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"🎄Ismingizni yozib ⛄Menga Yuboring!
❄Men Sizga Rasm Tayyorlab beraman!",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'resize_keyboard'=>false,
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"❌Orqaga"]],

]
])
]);
}
elseif($Yalqov1 == "to"){
$ex=$text;
$ex=$text;
bot('SendMessage',[
'chat_id'=>$chat_id,
 'text'=>"🌨Iltimos biroz kuting, buyurtmangiz hozir tayyor bo'ladi...",
 'parse_mode'=>"HTML"
 ]);
 sleep(1.1);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'text'=>'⛄Tayyorlanmoqda...
☁☁☁☁☁☁☁☁☁☁ 0% 0️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid +1,
 'text'=>'⛄Tayyorlanmoqda...
🌨☁☁☁☁☁☁☁☁☁ 10% 1️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨☁☁☁☁☁☁☁☁ 20% 2️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨☁☁☁☁☁☁☁ 30% 3️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨☁☁☁☁☁☁ 40% 4️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨☁☁☁☁☁ 50% 5️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨☁☁☁☁ 60% 6️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨☁☁☁ 70% 7️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨☁☁ 80% 8️⃣'
]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨🌨☁ 90% 9️⃣'
 ]);
 sleep(0.3);
 bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨🌨🌨 100% 🔟'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$cid,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyor 100%🎉'
 ]); 
  bot('deletemessage',[
    'chat_id'=>$cid,
    'message_id'=>$mid + 1,
  ]);
 sleep(0.5);
bot('sendphoto',[
'chat_id'=>$cid,
'photo'=>"http://u8481.xvest6.ru/Apilar/Fildirbot/Qizlarga/2/2.php?text=$ex",
'caption'=>"⛄Buyurtma qilgan Rasmingiz tayyor bo'ldi!
🎄Ismingiz: $ex

",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'resize_keyboard'=>false,
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"5"],['text'=>"❌Orqaga"]],
]
])
]);
unlink("data/$from_id/Yalqov1.txt");
exit();
}

if($text=="2" || $text == "2"){
file_put_contents("data/$from_id/Yalqov1.txt", 'to');
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"🎄Ismingizni yozib ⛄Menga Yuboring!
❄Men Sizga Rasm Tayyorlab beraman!",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'resize_keyboard'=>false,
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"❌Orqaga"]],

]
])
]);
}
elseif($Yalqov1 == "to"){
$ex=$text;
$ex=$text;
bot('SendMessage',[
'chat_id'=>$chat_id,
 'text'=>"🌨Iltimos biroz kuting, buyurtmangiz hozir tayyor bo'ladi...",
 'parse_mode'=>"HTML"
 ]);
 sleep(1.1);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'text'=>'⛄Tayyorlanmoqda...
☁☁☁☁☁☁☁☁☁☁ 0% 0️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid +1,
 'text'=>'⛄Tayyorlanmoqda...
🌨☁☁☁☁☁☁☁☁☁ 10% 1️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨☁☁☁☁☁☁☁☁ 20% 2️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨☁☁☁☁☁☁☁ 30% 3️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨☁☁☁☁☁☁ 40% 4️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨☁☁☁☁☁ 50% 5️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨☁☁☁☁ 60% 6️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨☁☁☁ 70% 7️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨☁☁ 80% 8️⃣'
]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨🌨☁ 90% 9️⃣'
 ]);
 sleep(0.3);
 bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨🌨🌨 100% 🔟'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$cid,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyor 100%🎉'
 ]); 
  bot('deletemessage',[
    'chat_id'=>$cid,
    'message_id'=>$mid + 1,
  ]);
 sleep(0.5);
bot('sendphoto',[
'chat_id'=>$cid,
'photo'=>"http://u8481.xvest6.ru/Apilar/Fildirbot/Yigitlar/2/2.php?text=$ex",
'caption'=>"⛄Buyurtma qilgan Rasmingiz tayyor bo'ldi!
🎄Ismingiz: $ex

",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'resize_keyboard'=>false,
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"2"],['text'=>"❌Orqaga"]],
]
])
]);
unlink("data/$from_id/Yalqov1.txt");
exit();
}

if($text=="3" || $text == "3"){
file_put_contents("data/$from_id/Yalqov1.txt", 'to');
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"🎄Ismingizni yozib ⛄Menga Yuboring!
❄Men Sizga Rasm Tayyorlab beraman!",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'resize_keyboard'=>false,
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"❌Orqaga"]],

]
])
]);
}
elseif($Yalqov1 == "to"){
$ex=$text;
$ex=$text;
bot('SendMessage',[
'chat_id'=>$chat_id,
 'text'=>"🌨Iltimos biroz kuting, buyurtmangiz hozir tayyor bo'ladi...",
 'parse_mode'=>"HTML"
 ]);
 sleep(1.1);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'text'=>'⛄Tayyorlanmoqda...
☁☁☁☁☁☁☁☁☁☁ 0% 0️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid +1,
 'text'=>'⛄Tayyorlanmoqda...
🌨☁☁☁☁☁☁☁☁☁ 10% 1️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨☁☁☁☁☁☁☁☁ 20% 2️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨☁☁☁☁☁☁☁ 30% 3️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨☁☁☁☁☁☁ 40% 4️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨☁☁☁☁☁ 50% 5️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨☁☁☁☁ 60% 6️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨☁☁☁ 70% 7️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨☁☁ 80% 8️⃣'
]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨🌨☁ 90% 9️⃣'
 ]);
 sleep(0.3);
 bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨🌨🌨 100% 🔟'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$cid,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyor 100%🎉'
 ]); 
  bot('deletemessage',[
    'chat_id'=>$cid,
    'message_id'=>$mid + 1,
  ]);
 sleep(0.5);
bot('sendphoto',[
'chat_id'=>$cid,
'photo'=>"http://u8481.xvest6.ru/Apilar/Fildirbot/Yigitlar/3/2.php?text=$ex",
'caption'=>"⛄Buyurtma qilgan Rasmingiz tayyor bo'ldi!
🎄Ismingiz: $ex

",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'resize_keyboard'=>false,
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"3"],['text'=>"❌Orqaga"]],
]
])
]);
unlink("data/$from_id/Yalqov1.txt");
exit();
}

if($text=="4" || $text == "4"){
file_put_contents("data/$from_id/Yalqov1.txt", 'to');
bot('sendmessage',[
'chat_id'=>$cid,
'text'=>"🎄Ismingizni yozib ⛄Menga Yuboring!
❄Men Sizga Rasm Tayyorlab beraman!",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'resize_keyboard'=>false,
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"❌Orqaga"]],

]
])
]);
}
elseif($Yalqov1 == "to"){
$ex=$text;
$ex=$text;
bot('SendMessage',[
'chat_id'=>$chat_id,
 'text'=>"🌨Iltimos biroz kuting, buyurtmangiz hozir tayyor bo'ladi...",
 'parse_mode'=>"HTML"
 ]);
 sleep(1.1);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'text'=>'⛄Tayyorlanmoqda...
☁☁☁☁☁☁☁☁☁☁ 0% 0️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid +1,
 'text'=>'⛄Tayyorlanmoqda...
🌨☁☁☁☁☁☁☁☁☁ 10% 1️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨☁☁☁☁☁☁☁☁ 20% 2️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨☁☁☁☁☁☁☁ 30% 3️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨☁☁☁☁☁☁ 40% 4️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨☁☁☁☁☁ 50% 5️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨☁☁☁☁ 60% 6️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨☁☁☁ 70% 7️⃣'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨☁☁ 80% 8️⃣'
]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨🌨☁ 90% 9️⃣'
 ]);
 sleep(0.3);
 bot('editMessageText',[
 'chat_id'=>$chat_id,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyorlanmoqda...
🌨🌨🌨🌨🌨🌨🌨🌨🌨🌨 100% 🔟'
 ]);
 sleep(0.3);
bot('editMessageText',[
 'chat_id'=>$cid,
 'message_id'=>$mid + 1,
 'text'=>'⛄Tayyor 100%🎉'
 ]); 
  bot('deletemessage',[
    'chat_id'=>$cid,
    'message_id'=>$mid + 1,
  ]);
 sleep(0.5);
bot('sendphoto',[
'chat_id'=>$cid,
'photo'=>"http://u8481.xvest6.ru/Apilar/Fildirbot/Qizlarga/1/2.php?text=$ex",
'caption'=>"⛄Buyurtma qilgan Rasmingiz tayyor bo'ldi!
🎄Ismingiz: $ex

",
'parse_mode'=>'HTML',
'reply_markup'=>json_encode([
'resize_keyboard'=>false,
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"4"],['text'=>"❌Orqaga"]],
]
])
]);
unlink("data/$from_id/Yalqov1.txt");
exit();
}




?>