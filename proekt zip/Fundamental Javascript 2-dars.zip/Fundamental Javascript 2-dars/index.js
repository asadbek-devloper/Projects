"use strict";

// VARIABLES

// let, const, var

// let
// let name1 = "Alisher";
// let num1;

// let num = 34;
// console.log(name1);

// name1 = "Usmon";

// console.log(name1);

// name1 = 89;
// console.log(name1);

// // const

// const name2 = "Komil";

// console.log(name2);

// name2 = "Davron"; TypeError
// const num3 ;      SyntaxError

// var

var name4 = "Aliy";

// DATA TYPES

// PRIMITIVE
// REFERENCE

// number

let age = 14;
let weight = 52.5;

let type = typeof age;

console.log(typeof weight);

console.log(age - "a");
console.log(typeof (age - "5"));
console.log(typeof ("5" + age));

console.log(100 ** 1000);
console.log(2 ** 53);

// string

("");
("");
``;

const name1 = "G'ofur";
const name2 = "G'ofur 'n jidsdsjn dsj sdjnsd'";
const name3 = `"" '' ${name1}  ${age}`;

console.log(name3);
console.log("name3: ", typeof name3);

// boolean

const isTall = true;
const isNotTall = false;

console.log(isNotTall);
console.log(isTall);
console.log("isTall", typeof isTall);

// null;

let null1 = null;

console.log("null: ", typeof null1);

// undefined

const un = undefined;

console.log(un);
console.log("un: ", typeof un);

// bigInt
const bigInt = 9007199254740991n;

console.log(typeof bigInt);
