<?php
ob_start();
ini_set('display_errors', 1);
error_reporting(0);
date_default_timezone_set("asia/Tashkent");
$sana=date("d.m.Y");
$sek = date("s");
$token="6253896826:AAEzPXg5MrneO4Cz2Y26e0DeeUevvsg-DYo";
$admin = "5873817487";
$botid = "6253896826";
$bot="Durdona_2oo7_bot";



$db = mysqli_connect("localhost", "login", "parol", "login");
mysqli_set_charset($db, "utf8mb4");

//tablo
mysqli_query($db,"CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` text NOT NULL,
  `sana` text NOT NULL,
  `step` text NOT NULL,
  PRIMARY KEY (`id`)
)");

mysqli_query($db,"CREATE TABLE `groups` (
`id` int(11) NOT NULL AUTO_INCREMENT,
 `chat_id` text NOT NULL,
PRIMARY KEY (`id`)
)");

function bot($method,$datas=[]){
global $token;
$datas["parse_mode"] = "HTML";
$datas["disable_web_page_preview"] = "true";
    $url = "https://api.telegram.org/bot".$token."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}



$update = json_decode(file_get_contents("php://input"));
$msgs = json_decode(file_get_contents('msgs.json'),true);
$message = $update->message;
$cid = $message->chat->id;
$chat_id = $message->chat->id;
$uid = $message->from->id;
$mid = $message->message_id;
$type = $message->chat->type;
$text = $message->text; $mtext = $message->text;
$name = $message->chat->first_name."  ".$message->chat->last_name;
$title = $message->chat->title;
$data = $update->callback_query->data;
$cid2 = $update->callback_query->message->chat->id;
$uid2 = $update->callback_query->from->id;
$mid2 = $update->callback_query->message->message_id;
$qid = $update->callback_query->id; 
$yangi = $message->new_chat_member;
$chiqdi = $message->left_chat_member;
$chiqid = $message->left_chat_member->id;
$kirid = $message->new_chat_member->id;
$newname = $message->new_chat_member->first_name;
if(isset($update)){
if($type == "private"){
$result = mysqli_query($db, "SELECT * FROM users WHERE user_id = '$uid'");
$row = mysqli_fetch_assoc($result);
if($row){
}else{
mysqli_query($db, "INSERT INTO users(user_id,sana,lang) VALUES ('$uid','$sana','nol')");
}
}}



if(isset($update)){
if($type=="group" or $type=="supergroup"){
$result = mysqli_query($db, "SELECT * FROM groups WHERE chat_id = '$cid'");
$row = mysqli_fetch_assoc($result);
if($row){
}else{
mysqli_query($db, "INSERT INTO groups(chat_id) VALUES ('$cid')");
}
}}


$resultv = mysqli_query($db, "SELECT * FROM users WHERE user_id = '$cid'");
$check = mysqli_fetch_assoc($resultv);
$step = $check['step'];

$g = json_encode([
'inline_keyboard'=>[
[['text'=>"Guruhga Qoʻshish ⤴️",'url'=>"http://t.me/$bot?startgroup=new"]],
]
]);


if(mb_stripos($text,"/start@$bot")!==false){ 
if($type=="group" or $type=="supergroup"){
bot('sendmessage',[
	'chat_id'=>$cid,
	  'text'=>"👋 <b>Salom meni ismim Durdona ❤️

Men guruhlarda gaplashuvchi botman meni ishlatish uchun guruhga qoʻshing va admin qiling 😊 </b>",
	
'reply_to_message_id'=>$mid,
	'reply_markup'=>$g,
]);
exit();
}else{
bot('sendmessage',[
	'chat_id'=>$cid,
	'text'=>"<b>❗ Ushbu buyruq guruhlarda ishlaydi</b>",
'reply_to_message_id'=>$mid,
	'reply_markup'=>$g,
]);
exit();
}}

if(mb_stripos($text,"/start")!==false){ 
if($type=="private"){
bot('sendmessage',[
	'chat_id'=>$cid,
	  'text'=>"👋 <b>Salom meni ismim Durdona❤️

Men guruhlarda gaplashuvchi botman meni ishlatish uchun guruhga qoʻshing va admin qiling 😊 </b>",
	
'reply_to_message_id'=>$mid,
	'reply_markup'=>$g,
]);
exit();
}else{
bot('sendmessage',[
	'chat_id'=>$cid,
	'text'=>"<b>❤️🥺 lichkamga yozing</b>",
'reply_to_message_id'=>$mid,
	//'reply_markup'=>$g,
]);
exit();
}}
///

if($kirid == $botid){
   bot('sendmessage',[
   'chat_id'=>$cid,
   'text'=>"☺️ <i>Men</i> <b>$title</b> <i>guruhida ishga tushdim!!</i>

🤗 <b>Toʻliq ishlashim uchun admin berishingiz kerak! @$bot</b>",
   'reply_markup'=>$g,
]);
}

  if($chiqdi == $uid){
    bot('deleteMessage',[
    'chat_id'=>$cid,
    'message_id'=>$mid,
]);
}
if($yangi){
  if($kirid == $uid){
    bot('deleteMessage',[
    'chat_id'=>$cid,
    'message_id'=>$mid,
]);
  bot('sendMessage',[
  'chat_id'=>$cid,
  'message_id'=>$mid,
  'text'=>"<i><b>👋 Salom</b> <a href='tg://user?id=$kirid'>$newname</a> Gruppamizga xush kelibsiz 😉</i>",
  //'reply_markup'=>$g,
]);
}
}


///soʻzlar
if((stripos($mtext,"Zo‘r") !== false) or (stripos($mtext,"yaxshi")!==false) or (stripos($mtext,"Zor")!==false) or (stripos($mtext,"Zo'r")!==false)){
	if($type=="group" or $type=="supergroup"){
  $name = $message->from->first_name;
  $input = array("Qayerdansiz asalim?","Juda  yaxshi asalim😁","Hm qales endi","Ok asalim.","Qaysi viloyatdansiz asalim?", "Nima uchun asalim","Har doim shunday bo'lsin asalim.","Qayerliksiz asalim?");
  $rand=rand(0,7);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
  'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
   'parse_mode'=> 'markdown'
  ]));
}
}



if((stripos($mtext,"xa") !== false) or (stripos($mtext,"Xa")!==false) or (stripos($mtext,"Ha")!==false) or (stripos($mtext,"ha")!==false)){
	if($type=="group" or $type=="supergroup"){
  $name = $message->from->first_name;
  $input = array("Qayerdansiz asalim?","Juda  yaxshi asalim😁","Hm qales endi","Ok asalim.","Qaysi viloyatdansiz asalim?", "Nima uchun asalim","Har doim shunday bo'lsin asalim.","Qayerliksiz asalim?");
  $rand=rand(0,7);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
  'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
   'parse_mode'=> 'markdown'
  ]));
}
}




if((stripos($mtext,"Toshkent")!==false) or (stripos($mtext,"Andijon")!==false) or (stripos($mtext,"Fargona")!==false) or (stripos($mtext,"Farg'ona")!==false)  or  (stripos($mtext,"Namangan")!==false) or  (stripos($mtext,"Sirdaryo")!==false) or (stripos($mtext,"Jizzax")!==false) or (stripos($mtext,"Qashqadaryo")!==false) or (stripos($mtext,"Surxondaryo")!==false) or (stripos($mtext,"Bukhara")!==false) or (stripos($mtext,"Xorazim")!==false) or (stripos($mtext,"Nukus")!==false) or (stripos($mtext,"Qoraqalpoq")!==false)  or  (stripos($mtext,"Qarshidan")!==false) or  (stripos($mtext,"Guliston")!==false) or (stripos($mtext,"Qoqon")!==false) or (stripos($mtext,"qo‘qonl")!==false) or (stripos($mtext,"Qo'qon")!==false) or (stripos($mtext,"Kattakorgon")!==false) or (stripos($mtext,"Chilonzor")!==false)){
	if($type=="group" or $type=="supergroup"){
$input = array("Qayeridan?","Zo'rku👍","Hmm,Chiroyli shahar","Yaxshi,lekin biz tomondan ancha uzoq ekan.","O‘zidanmi?", "Yoge,zorku.","Qayeridan.","Hm,u yerda chiroyli joylar ko‘p deb eshitganman.");
  $rand=rand(0,7);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
   'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
   'parse_mode'=> 'markdown'
  ]));
}
}

if((stripos($mtext,"hmm") !== false) or (stripos($mtext,"xmm")!==false)){
	if($type=="group" or $type=="supergroup"){
  $name = $message->from->first_name;
  $input = array("Nega  hmm deysiz gapiring asalim","Hmmmmmmmmmm","Nima hmm?","😂","Zeriktizmi asalim?","Negadur zerikdim", "Tinchlikmi?","Mb kam qoldimi deyman😁","Qayerliksiz?");
  $rand=rand(0,8);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
  'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
   'parse_mode'=> 'markdown'
  ]));
}
}

if((stripos($mtext,"tinchlikmi") !== false)){
if($type=="group" or $type=="supergroup"){
  $name = $message->from->first_name;
  $input = array("Ha tinchlik","Nima edi?","O'zizdan so'rasak");
  $rand=rand(0,2);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
   'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
   'parse_mode'=> 'markdown'
  ]));
}
}

if((stripos($mtext,"rostdanmi") !== false) or (stripos($mtext,"rostanmi")!==false) or (stripos($mtext,"rostmi")!==false)){
	if($type=="group" or $type=="supergroup"){
  $name = $message->from->first_name;
  $input = array("Ha rost","Bilmadim","Ha","Men qayerdan bilay ","Yolg'ondan :)");
  $rand=rand(0,4);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
   'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
   'parse_mode'=> 'markdown'
  ]));
}
}

if((stripos($mtext,"ozidan") !== false) or (stripos($mtext,"o'zidan")!==false) or (stripos($mtext,"o‘zidan")!==false) or (stripos($mtext,"sentridan")!==false)){
	if($type=="group" or $type=="supergroup"){
  $name = $message->from->first_name;
  $input = array("Ha yaxshi","Shahardanmisiz?","Zo'rku");
  $rand=rand(0,2);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
  'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
   'parse_mode'=> 'markdown'
  ]));
}
}

if((stripos($mtext,"Buxoro")!==false)){
	if($type=="group" or $type=="supergroup"){
$input = array("Wow, men ham buxorolik","Hamshahar  ekanmiz☺️","Men ham Buxorodan 😊","Qayeridan?","Bitta joydan ekanmiz");
  $rand=rand(0,4);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
   'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
   'parse_mode'=> 'markdown'
  ]));
}
}

if((stripos($mtext,"yoge")!==false) or (stripos($mtext,"rostanmi")!==false)  or (stripos($mtext,"rostdanmi")!==false)  or (stripos($mtext,"yog'e")!==false)){
if($type=="group" or $type=="supergroup"){
  $input = array("Ha","Ha shunaqa","Hm shunday","Haye.","Ha rost");
  $rand=rand(0,4);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
   'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
   'parse_mode'=> 'markdown'
  ]));
}
}

  if((stripos($mtext,"Salom") !== false) or (stripos($mtext,"салом")!==false)){
 if($type=="group" or $type=="supergroup"){
  $name = $message->from->first_name;
  $input = array("Assalom","Salom $name ,guruhimiz sizga yoqtimi?","Salom, ismiz nima?","Assaalomu alaykum","Привет, как дело?","Qaleysiz?","Sizga ham salom","Salom.", "Salom qaleysiz?","Vaalaykum salom,baxtli bo‘ling😊.","Yaxshimisiz $name, namuncha ko‘rinmay ketdiz?", "Juda sersalom ekansiz☺️", "Assalomu aleykum.", "Salom $name.", "Iye keling,endi sizni eslab turgandik","Ana,yana bittasi keldi😂","Salom meni tanidizmi?","Salom bergan kishini...Xudo o‘nglar ishini.","Namuncha salom beruras","Salomim so‘lim-so‘lim  kitobdadur o‘ng  qo‘lim.Tringlab hech qoymagan telegramda chap qo‘lim🤣🤣🤣","Sizni ko‘radigan kun ham  bor ekanu!","Salom,yaxshimisiz?","Qaleysiz?","Asssalomu alekooom boy ota.Ishlar qaley?","Sava","Привет ","Hello $name,qaleysiz?","Salom.Nik daxshatu a?","Ehe keb qoling, anu gap nima bo'ldi?","Yuragizni sevgi muhabbat qoplagan vaqda to‘g‘ri shu yerga kelevering,ok?","Garov  o‘ynaymizmi  kimnidur sevib qolgansiz?Agar adashayotgan bo‘lsam,garov haqida unuting😆","Bolla, qizla bitta fikr bor!","Keling,sizni ham ko‘radigan  kun  bor ekanu");
  $rand=rand(0,32);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
  'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
   'parse_mode'=> 'markdown'
  ]));
}
  }

if(stripos($mtext,"kimni") !== false){
	if($type=="group" or $type=="supergroup"){
  $input  = array("Bilmasam?","Anavi nasibani","Bugun havo zoru a?","Men bilmayman");
  $rand=rand(0,3);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
'reply_to_message_id'=>$mid,
    'chat_id'=>$cid,
    'text'=>$soz,
   ]));
}
}


if(stripos($mtext,"qanaqa") !== false){
	if($type=="group" or $type=="supergroup"){
  $input  = array("Man qayerdan bilay?","Hech qanaqa😆","Shunaqa","Bilmasam");
  $rand=rand(0,3);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
'reply_to_message_id'=>$mid,
    'chat_id'=>$cid,
    'text'=>$soz,
   ]));
}
}


if((stripos($mtext,"qaleys") !== false) or (stripos($mtext,"qalaysan")!==false)  or 
(stripos($mtext,"qaleysiz")!==false)  or 
(stripos($mtext,"qaliysan")!==false) or (stripos($mtext,"qaneysan")!==false)  or  (stripos($mtext,"qanneysan")!==false)){
	if($type=="group" or $type=="supergroup"){
  $input = array("Chotki😁","Zo‘y.", "Zo‘r, o‘zizchi?","Kechagidan  yaxshi😁","Yaxshi,so‘raganingiz uchun rahmat!", "Norm.", "Zo‘y,o‘zizchi?", "Chidasa bo‘ladi👌");
  $rand=rand(0,7);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
  'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
   'parse_mode'=> 'markdown'
  ]));
}
}

if((stripos($mtext,"durdona") !== false) or (stripos($mtext,"Durdona") !== false) or (stripos($mtext,"Adminka") !== false) or (stripos($mtext,"adminka")!==false)){
	if($type=="group" or $type=="supergroup"){
  $input = array("Qaleysiz?","Har zamonda bir yozib turingda siz ham","Uydagilar erga tegasan deb qoymayapti","Glavnizdagi rasm 👍","Bugun hamma jim negadur","Boʻlay desang mustaqil 5 ga 1 kunda qil 😜","Admin ko'rinmaydimi???","Mb iz kam qopti😂", "Men shu yerdaman.", "Hov", "Shunaqa chaqirishiz juda ham yoqadida☺️", "Nima?", "Menda ishiz bormi?", "Hozir kimdur meni esladimi?","Tinchgina “ужин” qilishga ham qoyishmaydiye bular","Qulog‘im  sizda!","Labbay!","Eshitaman","Hozi kelaman mb kam qopti","Salom  biror nima kerakmi?","Shu ismni qayerdadur eshitganmanda🤔","Ana kapitan");
  $rand=rand(0,14);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
  'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
  ]));
}
}

if((stripos($mtext,"rahmat")!==false) or (stripos($mtext,"raxmat")!== false)){
	if($type=="group" or $type=="supergroup"){
  $input = array("😊Arzimaydi","Arziysiz","😊","Rahmatga hojat yo‘q☺️");
  $rand=rand(0,3);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
   'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
  ]));
}
}

if((stripos($mtext,"😂")!==false) or 
(stripos($mtext,"😆")!== false)){
	if($type=="group" or $type=="supergroup"){
  $input = array("Chiroyli Kularkansiz","Kulavermange","😆😆","😒😒");
  $rand=rand(0,3);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
   'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
  ]));
}
}

if((stripos($mtext,"😆")!==false) or (stripos($mtext,"🤣")!== false)){
	if($type=="group" or $type=="supergroup"){
  $input = array("Ha Nima Boldi🤣","🤣🤣","Vaxaxaxaxaxa Juda Kulgili A","😒😒");
  $rand=rand(0,3);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
   'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
  ]));
}
}

if((stripos($mtext,"😒")!==false) or (stripos($mtext,"😏")!== false)){
	if($type=="group" or $type=="supergroup"){
  $input = array("Ha Nima Boldi","Hafa Korinasiz","Jahliz Chiqyaptimi","Sizga Hafa Bolish Yarashmas Ekan");
  $rand=rand(0,3);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
   'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
  ]));
}
}

if((stripos($mtext,"man")!==false) or (stripos($mtext,"kim")!== false)){
	if($type=="group" or $type=="supergroup"){
  $input = array("Man ☹️","San","☹️","🤨");
  $rand=rand(0,3);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
   'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
  ]));
}
}

if((stripos($mtext,"yoq")!==false) or (stripos($mtext,"Yoq")!== false)){
	if($type=="group" or $type=="supergroup"){
  $input = array("Nima Yoq ☹️","Yoq Bolsa Yoqda","☹️","ble nimaga oka");
  $rand=rand(0,3);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
   'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
  ]));
}
}


if(stripos($mtext,"kimman") !== false){
if($type=="group" or $type=="supergroup"){
  $name = $message->from->first_name;
  $input = array("$name siz.","O‘ziz  bilmasaiz men qayerdan bilay?!","Betakrorsiz","Ajinagul...degan sinfdoshim esimga tushib ketdi😢","N1","Kapitan","Ponchik","Kunfu panda","Babniksiz?","Kim bo‘lsangiz  ham  avvalo inson bo’ling!","Bruslini  quritilgani😂","Boyvacha","Eng zo‘risiz","Man  qayerdan bilay");
  $rand=rand(0,13);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
   'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
  ]));
}
}

if(stripos($mtext,"kimsan")!== false){
	if($type=="group" or $type=="supergroup"){
  $name = $message->from->first_name;
  $input = array("Ammangni qiziman 😂","Poxxuy emasmi 😂.","Hazilkash robotcha!","kim deb o‘ylaysiz?","Xotiniz jon","Kapitan Telegram","@$bot, yana Masha bilan adashtirib yubormeng😂","xafliman bolakay","O‘ziz kimsiz?","Har doim shu savolni  beruvirib charchamadizmi?","Tinchlikmi kimligim bilan qiziqib qolibsiz!?","Menmi ?","Nima edi 😡...Vux qo‘rqib ketdiza?","Selena Gomes,","Aytsam sizni oldirishga togri keladi");
  $rand=rand(0,13);
  $soz="$input[$rand]";
  $a=json_encode(bot('sendmessage',[
   'reply_to_message_id'=>$mid,
   'chat_id'=>$cid,
   'text'=>$soz,
  ]));
}
}

$msgs = json_decode(file_get_contents('msgs.json'),true);
if($type=="supergroup" or $type=="group"){
    $ex = $msgs[$text];
$ex = explode(",",$ex);
    $txt = $ex[rand(0,count($ex)-1)];
bot("sendmessage",[
  'chat_id'=>$cid,
  'text'=>"$txt",
  'reply_to_message_id'=>$mid
  ]);
}

$replytx = $message->reply_to_message->text;
if($replytx){
    if($type=="supergroup"  or $type=="group"){

            if(strpos($msgs[$replytx],"$text") !==false){
    }else{
    $msgs[$replytx] ="$text,$msgs[$replytx]";
    file_put_contents('msgs.json', json_encode($msgs));
  }
  
}
}


?>